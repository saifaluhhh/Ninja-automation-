package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class cartpage {
	WebDriver driver;
	By selectproduct = By.xpath("//img[@title=\"MacBook\"]");
	By addproduct = By.id("button-cart");
	By succsessmsg = By.xpath("//div[text()=\"Success: You have added \"]");
	By clickshopingcart = By.xpath("//span[text()=\"Shopping Cart\"]");
	By removeproduct = By.xpath("//*[@id=\"content\"]/form/div/table/tbody/tr/td[4]/div/span/button[2]");
	By checkproductremve = By.xpath("//a[text()=\"MacBook\"]");
	By checkcartemtyrmoveallproduct = By.xpath("//p[text()=\"Your shopping cart is empty!\"]");

	public cartpage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickproduct() {
		driver.findElement(selectproduct).click();

	}

	public void clickaddtocart() {
		driver.findElement(addproduct).click();
	}

	public boolean succsessfullyaddedmsg() {
		return driver.findElement(succsessmsg).isDisplayed();
	}

	public void clickcart() {
		driver.findElement(clickshopingcart).click();

	}

	public void productremove() {
		driver.findElement(removeproduct).click();
	}

	public boolean checkproductremove() {
		return driver.findElements(checkproductremve).size() == 0;
	}

	public boolean afterrefreshproductvisible() {
		return driver.findElements(checkproductremve).size() > 0;
	}

	public boolean cartemtyrmoveallproduct() {
		return driver.findElements(checkcartemtyrmoveallproduct).size() > 0;
	}
}
