package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class checkoutpage {
	WebDriver driver;

	By clickcheckout = By.xpath("//span[text()='Checkout']");
	By visithomepage = By.xpath("//a[text()=\"Qafox.com\"]");

	public checkoutpage(WebDriver driver) {
		this.driver = driver;
	}

	public void checkoutclickbtn() {
		driver.findElement(clickcheckout).click();
	}

	public String currenturl() {
		return driver.getCurrentUrl();
	}

	public void visithome() {
		driver.findElement(visithomepage).click();
	}

}
