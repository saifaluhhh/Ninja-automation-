package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class footerpage {
	WebDriver driver;

	By about = By.xpath("//a[text()='About Us']");
	By privacypolicy = By.xpath("//a[text()='Privacy Policy']");
	By termsandconditions = By.xpath("//a[text()=\"Terms & Conditions\"]");
	By contact = By.xpath("//a[text()=\"Contact Us\"]");

	// verifying page
	By aboutpage = By.id("content");
	By privacypolicypage = By.xpath("//h1[text()='Privacy Policy']");
	By termsandconditionspage = By.xpath("//h1[text()='Terms & Conditions']");
	By contactpage = By.xpath("//h1[text()=\"Contact Us\"]");

	public footerpage(WebDriver driver) {
		this.driver = driver;

	}

	public void scrollfooter() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(0, document.body.scrollHeight);");

	}

	public void clickabout() {
		driver.findElement(about).click();
	}

	public boolean verifyaboutpage() {
		return driver.findElement(aboutpage).isDisplayed();
	}

	public void clickprivacypolicy() {
		driver.findElement(privacypolicy).click();
	}

	public boolean verifyprivacypolicypage() {
		return driver.findElement(privacypolicypage).isDisplayed();
	}

	public void clicktermsandconditions() {
		driver.findElement(termsandconditions).click();
	}

	public boolean verifytermsandconditionspage() {
		return driver.findElement(termsandconditionspage).isDisplayed();
	}

	public void clickcontact() {
		driver.findElement(termsandconditions).click();
	}

	public boolean verifycontactpage() {
		return driver.findElement(termsandconditionspage).isDisplayed();
	}

}