package pages;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.basetest;

public class footertest extends basetest {

//Verify about us page link opens correctly
	@Test(priority = 1)
	public void abouttest() {
		footerpage f = new footerpage(driver);
		// scroll to bottom of the page
		f.scrollfooter();

		// click on about link
		f.clickabout();

		// verify about page opened
		Assert.assertTrue(f.verifyaboutpage(), "about page not open");

	}

	// Verify privacy policy link opens correctly
	@Test(priority = 2)
	public void privacypolicytest() {
		footerpage f = new footerpage(driver);
		// scroll to bottom of the page
		f.scrollfooter();

		// click on privacy policy link
		f.clickprivacypolicy();

		// verify privacy policy page opened
		Assert.assertTrue(f.verifyprivacypolicypage(), "about page not open");

	}

	// Verify terms and conditions link opens correctly
	@Test(priority = 3)
	public void termsandconditionstest() {
		footerpage f = new footerpage(driver);
		// scroll to bottom of the page
		f.scrollfooter();

		// click on termsandconditions link
		f.clicktermsandconditions();

		// verify termsandconditions page opened
		Assert.assertTrue(f.verifytermsandconditionspage(), " termsandconditions page not open");

	}

	// Verify contact us link opens correctly
	@Test(priority = 4)
	public void contacttest() {
		footerpage f = new footerpage(driver);
		// scroll to bottom of the page
		f.scrollfooter();

		// click on termsandconditions link
		f.clickcontact();

		// verify termsandconditions page opened
		Assert.assertTrue(f.verifycontactpage(), "  contacttest page not open");

	}
}
