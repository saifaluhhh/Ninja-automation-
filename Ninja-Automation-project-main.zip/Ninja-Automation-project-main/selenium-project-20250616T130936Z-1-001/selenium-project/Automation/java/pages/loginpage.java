package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginpage {
	WebDriver driver;

	By clickmyaccount = By.xpath("//span[text()=\"My Account\"]");
	By clicklogin = By.xpath("//a[text()=\"Login\"]");
	By enteremail = By.id("input-email");
	By enterpassword = By.id("input-password");
	By clickloginbtn = By.xpath("//input[@value=\"Login\"]");
	By clicklogout = By.xpath("//a[text()=\"Logout\"]");
	// error and succsess msg
	By incorrectdetailerrormsg = By.xpath("//div[text()=\"Warning: No match for E-Mail Address and/or Password.\"]");
	By logoutmsg = By.xpath("//h1[text()=\"Account Logout\"]");

	public loginpage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickaccount() {
		driver.findElement(clickmyaccount).click();
	}

	public void clogin() {
		driver.findElement(clicklogin).click();
	}

	public void entere(String email) {
		driver.findElement(enteremail).sendKeys(email);
		;
	}

	public void enterpass(String password) {
		driver.findElement(enterpassword).sendKeys(password);

	}

	public void cloginbtn() {
		driver.findElement(clickloginbtn).click();
	}

	public boolean logoutbtnvisble() {
		return driver.findElement(clicklogout).isDisplayed();
	}

	public boolean errormsg() {
		return driver.findElement(incorrectdetailerrormsg).isDisplayed();
	}

	public void logoutbtn() {
		driver.findElement(clicklogout).click();
	}

	public boolean logoutmsg() {
		return driver.findElement(logoutmsg).isDisplayed();
	}

}
