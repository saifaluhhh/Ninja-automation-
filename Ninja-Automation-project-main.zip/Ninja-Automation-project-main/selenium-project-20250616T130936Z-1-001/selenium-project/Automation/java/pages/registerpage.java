package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class registerpage {
	WebDriver driver;

	By myaccount = By.xpath("//span[text()=\"My Account\"]");
	By register = By.xpath("//a[text()=\"Register\"]");
	By firstname = By.id("input-firstname");
	By lastname = By.id("input-lastname");
	By email = By.id("input-email");
	By telephone = By.id("input-telephone");
	By password = By.id("input-password");
	By passwordconfirm = By.id("input-confirm");
	By newsletter = By.xpath("//*[@id=\"content\"]/form/fieldset[3]/div/div/label[1]/input");
	By checkbox = By.xpath("//input[@type=\"checkbox\"]");
	By submitbtn = By.xpath("//input[@type=\"submit\"]");

	// error and success messages
	By firstnameerror = By.xpath("//div[text()=\"First Name must be between 1 and 32 characters!\"]");
	By lastnameerror = By.xpath("//div[text()=\"Last Name must be between 1 and 32 characters!\"]");
	By emailvalidationerror = By.xpath("//div[text()=\"E-Mail Address does not appear to be valid!\"]");
	By telephonevalidationerror = By.xpath("//div[text()=\"Telephone must be between 3 and 32 characters!\"]");
	By passwordavlidationerror = By.xpath("//*[contains(text(),'Password must be between')]");
	By succsessmsgBy = By.xpath("//h1[text()=\"Your Account Has Been Created!\"]");
	By existemailerror = By.xpath("//div[text()=\"Warning: E-Mail Address is already registered!\"]");

	public registerpage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickmyaccount() {
		driver.findElement(myaccount).click();
	}

	public void clickregister() {
		driver.findElement(register).click();
	}

	public void enterfirstname(String fname) {
		driver.findElement(firstname).sendKeys(fname);
	}

	public void enterlastname(String lname) {
		driver.findElement(lastname).sendKeys(lname);
	}

	public void enteremail(String e) {
		driver.findElement(email).sendKeys(e);
	}

	public void entertelephone(String tn) {
		driver.findElement(telephone).sendKeys(tn);
	}

	public void enterpassword(String pass) {
		driver.findElement(password).sendKeys(pass);
	}

	public void enterpasswordconfirm(String cp) {
		driver.findElement(passwordconfirm).sendKeys(cp);
	}

	public void checknewsletter() {
		driver.findElement(newsletter).click();
	}

	public void checkcheckbox() {
		driver.findElement(checkbox).click();
	}

	public void clicksubmitbtn() {
		driver.findElement(submitbtn).click();
	}

	public boolean fnameerrormsg() {
		return driver.findElement(firstnameerror).isDisplayed();
	}

	public boolean lnameerrormsg() {
		return driver.findElement(lastnameerror).isDisplayed();
	}

	public boolean emailerror() {
		return driver.findElement(emailvalidationerror).isDisplayed();
	}

	public boolean noerrormsg() {
		return driver.findElement(telephonevalidationerror).isDisplayed();
	}

	public boolean passerrormsg() {
		return driver.findElement(passwordavlidationerror).isDisplayed();
	}

	public boolean succsessmsg() {
		return driver.findElement(succsessmsgBy).isDisplayed();
	}

	public boolean existemailmsg() {
		return driver.findElement(existemailerror).isDisplayed();
	}

}
