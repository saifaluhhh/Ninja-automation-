package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class responsivepage {
	WebDriver driver;

	By menuicon = By.xpath("//*[@id=\"menu\"]/div[1]/button");
	By searchbtn = By.xpath("//*[@id=\"search\"]/span/button");
	By productimg = By.xpath("//img[@title=\"MacBook\"]");
	By productprice = By.xpath("//p[@class=\"price\"]");
	By productdescription = By.xpath("//*[@id=\"content\"]/div[2]/div[1]/div/div[2]/p[1]/text()");

	public responsivepage(WebDriver driver) {
		this.driver = driver;
	}

	public void scroll() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 400);");
	}

	public boolean menuiconvisible() {
		return driver.findElement(menuicon).isDisplayed();
	}

	public boolean searchbtnvisible() {
		return driver.findElement(searchbtn).isDisplayed();
	}

	public boolean productimgvisible() {
		return driver.findElement(productimg).isDisplayed();
	}

	public boolean productpricevisible() {
		return driver.findElement(productprice).isDisplayed();
	}

	public boolean productdescriptionisible() {
		return driver.findElement(productprice).isDisplayed();
	}

}
