package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class searchpage {
	WebDriver driver;

	By inputbox = By.xpath("//input[@placeholder=\"Search\"]");
	By searcbtn = By.xpath("//div[@id='search']//button");

	By validproduct = By.xpath("//a[text()=\"iPhone\"]");
	By invalidsearchmsg = By.xpath("//p[text()=\"There is no product that matches the search criteria.\"]");

	public searchpage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickinputbox(String product) {
		driver.findElement(inputbox).clear();
		driver.findElement(inputbox).sendKeys(product);
	}

	public void clicsearchbtn() {
		driver.findElement(searcbtn).click();
	}

	public boolean validsearch() {
		return driver.findElement(validproduct).isDisplayed();
	}

	public boolean invalidsearcherrormsg() {
		return driver.findElement(invalidsearchmsg).isDisplayed();
	}

}
