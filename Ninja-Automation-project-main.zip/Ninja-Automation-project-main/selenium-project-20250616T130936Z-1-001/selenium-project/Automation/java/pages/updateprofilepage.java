package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class updateprofilepage {
	WebDriver driver;

	By clickeditinfo = By.xpath("//a[text()='Edit your account information']");
	By updatefirstname = By.xpath("//input[@id=\"input-firstname\"]");
	By clicksubmitbtn = By.xpath("//input[@value=\"Continue\"]");
	By updateemail = By.id("input-email");
	// error and succsess msg
	By succsmsg = By.xpath("//div[text()=\"Success: Your account has been successfully updated.\"]");
	By emtyemailerrormsg = By.xpath("//input[@value=\"Continue\"]");

	public updateprofilepage(WebDriver driver) {
		this.driver = driver;
	}

	public void editimfo() {
		driver.findElement(clickeditinfo).click();
	}

	public void editname(String nameu) {
		driver.findElement(updatefirstname).clear();
		driver.findElement(updatefirstname).sendKeys(nameu);
	}

	public void clickbtn() {
		driver.findElement(clicksubmitbtn).click();
	}

	public boolean succmsg() {
		return driver.findElement(succsmsg).isDisplayed();
	}

	public void emailupdate() {
		driver.findElement(updateemail).clear();
	}

	public boolean emtymailerrormsg() {
		return driver.findElement(emtyemailerrormsg).isDisplayed();
	}

	public String firstnamevalue() {
		return driver.findElement(updatefirstname).getAttribute("value");
	}

}
