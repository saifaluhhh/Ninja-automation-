package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.basetest;
import pages.cartpage;

public class carttest extends basetest {

	// Verify adding product to cart
	@Test(priority = 1)
	public void addproduct() {
		cartpage atc = new cartpage(driver);
		// click on product
		atc.clickproduct();
		// click addtocart btn
		atc.clickaddtocart();

		// check product added msg
		Assert.assertTrue(atc.succsessfullyaddedmsg(), "added msg not visible");
	}

	// Verify removing product from cart
	@Test(priority = 2)
	public void removeingproduct() throws InterruptedException {
		cartpage atc = new cartpage(driver);

		// click on product
		atc.clickproduct();
		// click addtocart btn
		atc.clickaddtocart();
		// click cart
		atc.clickcart();
		// click remove btn
		atc.productremove();
		Thread.sleep(2000);

		// verfying product remove or not
		Assert.assertTrue(atc.checkproductremove(), "product not remove");

	}

	// Verify product visible after page refresh
	@Test(priority = 3)
	public void productvisibleafterrefresh() throws InterruptedException {
		cartpage atc = new cartpage(driver);
		// click on product
		atc.clickproduct();
		// click addtocart btn
		atc.clickaddtocart();

		// refresh page
		driver.navigate().refresh();
		Thread.sleep(2000);

		// click cart
		atc.clickcart();

		// check product added msg
		Assert.assertTrue(atc.afterrefreshproductvisible(), "product  not visible");
	}

	// Verify removing all product from cart and check cart is emty
	@Test(priority = 4)
	public void cartafterremoveallproductremty() throws InterruptedException {
		cartpage atc = new cartpage(driver);

		// click on product
		atc.clickproduct();
		// click addtocart btn
		atc.clickaddtocart();
		// click cart
		atc.clickcart();
		// click remove btn
		atc.productremove();
		Thread.sleep(4000);

		// verfying product remove or not
		Assert.assertTrue(atc.cartemtyrmoveallproduct(), "Cart is not empty after removing all items.");

	}
}
