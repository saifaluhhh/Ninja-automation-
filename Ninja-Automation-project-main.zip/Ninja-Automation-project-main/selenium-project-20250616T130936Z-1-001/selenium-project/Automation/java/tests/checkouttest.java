package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.basetest;
import pages.cartpage;
import pages.checkoutpage;
import pages.loginpage;

//Verify checkout page loads correctly
public class checkouttest extends basetest {
	@Test(priority = 1)
	public void verifycheckoutpage() {
		checkoutpage cp = new checkoutpage(driver);

		// click on checkout btn
		cp.checkoutclickbtn();

		// check checkout page open or not
		String currurl = cp.currenturl();
		String expurl = "https://tutorialsninja.com/demo/index.php?route=checkout/cart";

		Assert.assertEquals(currurl, expurl);
	}

	// Verify checkout process
	@Test(priority = 2)
	public void verifyingcheckoutprocess() {
		checkoutpage cp = new checkoutpage(driver);
		loginpage lg = new loginpage(driver);
		cartpage atc = new cartpage(driver);

		// login account
		// click on myaccount
		lg.clickaccount();

		// click on login
		lg.clogin();

		// enter email id
		lg.entere("ab17@gmail.com");

		// enter password
		lg.enterpass("123456");

		// click loginbtn
		lg.cloginbtn();

		// visit home page
		cp.visithome();

		// add product to cart
		// click on product
		atc.clickproduct();
		// click addtocart btn
		atc.clickaddtocart();

		// click checout btn
		cp.checkoutclickbtn();

	}
}