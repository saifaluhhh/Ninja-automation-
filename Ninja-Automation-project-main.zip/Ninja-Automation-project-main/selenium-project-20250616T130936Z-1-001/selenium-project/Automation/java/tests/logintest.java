package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.basetest;
import pages.loginpage;

public class logintest extends basetest {

	// verify acount login valid detail
	@Test(priority = 1)
	public void login() {
		loginpage lg = new loginpage(driver);

		// click on myaccount
		lg.clickaccount();

		// click on login
		lg.clogin();

		// enter email id
		lg.entere("ab17@gmail.com");

		// enter password
		lg.enterpass("123456");

		// click loginbtn
		lg.cloginbtn();

		// click on myaccount
		lg.clickaccount();

		// verify login succsessfuly
		Assert.assertTrue(lg.logoutbtnvisble(), "logout btn not visble");

	}

	// check error msg show with input box emty
	@Test(priority = 2)
	public void inputemtyerrormsg() {

		loginpage lg = new loginpage(driver);

		// click on myaccount
		lg.clickaccount();

		// click on login
		lg.clogin();

		// enter email id
		lg.entere("");

		// enter password
		lg.enterpass("");

		// click loginbtn
		lg.cloginbtn();

		// verifying error msg to login emty fild
		Assert.assertTrue(lg.errormsg(), "error msg not visible");
	}

	// check logout functionality
	@Test(priority = 3)
	public void logout() {
		loginpage lg = new loginpage(driver);

		// click on myaccount
		lg.clickaccount();

		// click on login
		lg.clogin();

		// enter email id
		lg.entere("ab17@gmail.com");

		// enter password
		lg.enterpass("123456");

		// click loginbtn
		lg.cloginbtn();

		// click on myaccount
		lg.clickaccount();

		// click on logout btn
		lg.logoutbtn();

		// logout msg visible
		Assert.assertTrue(lg.logoutmsg(), " msg not visible");

	}

	// verify login stay after page refresh
	@Test(priority = 4)
	public void stayloginpagerefresh() throws InterruptedException {
		loginpage lg = new loginpage(driver);

		// click on myaccount
		lg.clickaccount();

		// click on login
		lg.clogin();

		// enter email id
		lg.entere("ab17@gmail.com");

		// enter password
		lg.enterpass("123456");

		// click loginbtn
		lg.cloginbtn();

		// refresh page
		driver.navigate().refresh();
		Thread.sleep(5000);

		// click on myaccount
		lg.clickaccount();

		// verify login stay after page refresh
		Assert.assertTrue(lg.logoutbtnvisble(), "logout btn not visble");
	}

}
