package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.basetest;
import pages.registerpage;

public class registertest extends basetest {

	// verify error msg when all inputs are empty
	@Test(priority = 1)
	public void registeremtyinputs() {

		// create page object
		registerpage rp = new registerpage(driver);

		// click on my account
		rp.clickmyaccount();

		// click on register
		rp.clickregister();

		// click on submit emty inputs
		rp.clicksubmitbtn();

		// check first name error is showing
		Assert.assertTrue(rp.fnameerrormsg(), "first name error not visible");

		// check last name error is showing
		Assert.assertTrue(rp.lnameerrormsg(), "last name error not visible");

		// check email error is showing
		Assert.assertTrue(rp.emailerror(), "email error not visible");

		// check number error is showing
		Assert.assertTrue(rp.noerrormsg(), "number error not visible");

		// check password error is showing
		Assert.assertTrue(rp.passerrormsg(), "password error not visible");
	}

	// verify register with valid details
	@Test(priority = 2)
	public void registervaliddetails() {
		// create page object
		registerpage rp = new registerpage(driver);

		// click on my account
		rp.clickmyaccount();

		// click on register
		rp.clickregister();

		// enter first name
		rp.enterfirstname("aftab");

		// enter last name
		rp.enterlastname("shaikh");

		// enter email
		rp.enteremail("ab17@gmail.com");

		// enter number
		rp.entertelephone("1234567890");

		// enter password
		rp.enterpassword("123456");

		// enter password confirm
		rp.enterpasswordconfirm("123456");

		// click on newsletter
		rp.checknewsletter();

		// click on agree checkbox
		rp.checkcheckbox();

		// click on submit button
		rp.clicksubmitbtn();

		// registration success message
		Assert.assertTrue(rp.succsessmsg(), "succsessmsg not visble");

	}

	// verify error msg for already used email
	@Test(priority = 3)
	public void registeralredyregisteremail() {

		// create page object
		registerpage rp = new registerpage(driver);

		// click on my account
		rp.clickmyaccount();

		// click on register
		rp.clickregister();

		// enter first name
		rp.enterfirstname("aftab");

		// enter last name
		rp.enterlastname("shaikh");

		// enter email
		rp.enteremail("ab17@gmail.com");

		// enter number
		rp.entertelephone("1234567890");

		// enter password
		rp.enterpassword("123456");

		// enter password confirm
		rp.enterpasswordconfirm("123456");

		// click on newsletter
		rp.checknewsletter();

		// click on agree checkbox
		rp.checkcheckbox();

		// click on submit button
		rp.clicksubmitbtn();

		// email exxist error msg
		Assert.assertTrue(rp.existemailmsg(), "email exist msg  not visble");

	}
}
