package tests;

import org.openqa.selenium.Dimension;
import org.testng.Assert;
import org.testng.annotations.Test;

import base.basetest;
import pages.responsivepage;

public class responsivetest extends basetest {

	// Verify menu bar are visible on tablet
	@Test(priority = 1)
	public void menutest() {
		responsivepage rp = new responsivepage(driver);

		// set screen size to mobile
		driver.manage().window().setSize(new Dimension(375, 667));

		// check menu icon is visible
		Assert.assertTrue(rp.menuiconvisible(), "menu not visible");
	}

	// Verify buttons are visible on tablet
	@Test(priority = 2)
	public void btntest() {
		responsivepage rp = new responsivepage(driver);

		// set screen size to mobile tablet
		driver.manage().window().setSize(new Dimension(375, 667));

		// check search button is visible
		Assert.assertTrue(rp.searchbtnvisible(), "search btn  not visible");
	}

	// Verify product image
	@Test(priority = 3)
	public void productimgtest() {
		responsivepage rp = new responsivepage(driver);

		// set mobile screen
		driver.manage().window().setSize(new Dimension(375, 667));
		// scroll to product
		rp.scroll();

		// check product image is visible
		Assert.assertTrue(rp.productimgvisible(), "product img  not visible");
	}

	// Verify product price
	@Test(priority = 4)
	public void productpricetest() {
		responsivepage rp = new responsivepage(driver);
		// set mobile screen
		driver.manage().window().setSize(new Dimension(375, 667));
		// scroll to product
		rp.scroll();

		// check price is visible
		Assert.assertTrue(rp.productpricevisible(), "product price not visible");
	}

	// Verify product description
	@Test(priority = 5)
	public void productdescriptiontest() {
		responsivepage rp = new responsivepage(driver);
		// set mobile screen
		driver.manage().window().setSize(new Dimension(375, 667));
		// scroll to product
		rp.scroll();

		// check product description is visible
		Assert.assertTrue(rp.productdescriptionisible(), "product description not visible");
	}
}
