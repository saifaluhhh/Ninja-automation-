package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.basetest;
import pages.searchpage;

public class searchtest extends basetest {

	// Verify product search without entering any text
	@Test(priority = 1)
	public void emtyinputsearch() throws InterruptedException {
		searchpage sp = new searchpage(driver);

		// search product emty value
		sp.clickinputbox("");
		// click search btn
		sp.clicsearchbtn();

		// verifying error msg visible
		Assert.assertTrue(sp.invalidsearcherrormsg(), "inavlid search Error msgError not visible");

	}

	@Test(priority = 2)
	public void validsearch() throws InterruptedException {
		searchpage sp = new searchpage(driver);

		// search product valid value
		sp.clickinputbox("iphone");
		// click search btn
		sp.clicsearchbtn();

		// verifying product visible
		Assert.assertTrue(sp.validsearch(), "valid search product  not visible");

	}

	@Test(priority = 3)
	public void invalidsearch() throws InterruptedException {
		searchpage sp = new searchpage(driver);

		// search product invalid value
		sp.clickinputbox("djh273673");
		// click search btn
		sp.clicsearchbtn();

		// verifying error msg visible
		Assert.assertTrue(sp.invalidsearcherrormsg(), "inavlid search Error msgError not visible");

	}

	@Test(priority = 4)
	public void specialcharacterssearch() throws InterruptedException {
		searchpage sp = new searchpage(driver);

		// search product special characters value
		sp.clickinputbox("@#$%");
		// click search btn
		sp.clicsearchbtn();

		// verifying error msg visible
		Assert.assertTrue(sp.invalidsearcherrormsg(), "inavlid search Error msgError not visible");

	}
}
