package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import base.basetest;
import pages.loginpage;
import pages.updateprofilepage;

public class updateprofiletest extends basetest {

	// Verify user can update profile details
	@Test(priority = 1)
	public void editinformation() throws InterruptedException {
		loginpage lg = new loginpage(driver);
		updateprofilepage up = new updateprofilepage(driver);

		// login on page
		lg.clickaccount();
		lg.clogin();
		lg.entere("ab17@gmail.com");
		lg.enterpass("123456");
		lg.cloginbtn();

		// verify login succsessfuly
		lg.clickaccount();
		Assert.assertTrue(lg.logoutbtnvisble(), "logout btn not visble");
		Thread.sleep(2000);

		// clear firstname fild and update name
		up.editimfo();

		up.editname("aftab");
		up.clickbtn();

		// verifying updaate succsessfully
		Assert.assertTrue(up.succmsg(), "succsess msg not visible");
		Thread.sleep(2000);
	}

	// Verify error message for invalid email update
	@Test(priority = 2)
	public void emtyemailerrormsg() throws InterruptedException {
		loginpage lg = new loginpage(driver);
		updateprofilepage up = new updateprofilepage(driver);

		// login on page
		lg.clickaccount();
		lg.clogin();
		lg.entere("ab17@gmail.com");
		lg.enterpass("123456");
		lg.cloginbtn();

		// clear email fild and click continubtn and check error msg visble
		up.editimfo();
		up.emailupdate();
		up.clickbtn();

		// verifying error msg visble
		Assert.assertTrue(up.emtymailerrormsg(), "emty email input error msg not visible");

	}

	// Verify profile update is saved after logout

	@Test(priority = 3)
	public void afeterlogoutprofilestayupdated() {
		loginpage lg = new loginpage(driver);
		updateprofilepage up = new updateprofilepage(driver);

		// login on page
		lg.clickaccount();
		lg.clogin();
		lg.entere("ab17@gmail.com");
		lg.enterpass("123456");
		lg.cloginbtn();

		// clear firstname fild and update name
		up.editimfo();
		up.editname("aftab17");
		up.clickbtn();

		// logout page
		lg.clickaccount();
		lg.logoutbtn();

		// login on page
		lg.clickaccount();
		lg.clogin();
		lg.entere("ab17@gmail.com");
		lg.enterpass("123456");
		lg.cloginbtn();

		// click to edit
		up.editimfo();

		// Verify updated name is still present
		String namevalue = up.firstnamevalue();
		Assert.assertTrue(namevalue.equals("aftab17"), "updated value not peresent");
	}

}
